# Project Scope Statement

## Project Purpose
To create a simple, clean personal website that introduces who I am, shares my background, and provides a clear way for visitors to contact me online.

## Description
A single-page, static website hosted online. Key components include:

- **About Section:** A short personal bio detailing background, skills, and current work.
- **Contact Info:** Links to email and professional social media profiles (e.g., LinkedIn, GitHub).
- **Responsive Layout:** Basic styling that renders cleanly on mobile, tablet, and desktop screens.

## Desired Results
- **Online Presence:** Establish a functional web address (URL) live on the web within 1-2 weeks.
- **Performance:** Fast load times under 2 seconds with zero navigation errors.
- **Clarity:** Visitors can immediately learn who I am and reach out in 1 click.

## Exclusions
- Custom domain registration (will use a free platform subdomain like Netlify or GitHub Pages).
- Multi-page navigation, blog engine, or content management system (CMS).
- Contact form backends or database integration (simple mailto and external links only).
- E-commerce, portfolio gallery showcases, or complex interactive JavaScript elements.
- Professional logo design or custom graphics.
